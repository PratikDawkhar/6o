//linked

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#define DISKSIZE 100
#define DIRSIZE 20

struct direntry
{
    char fname[14];
    struct blist *first;
    int deleted;
} dir[DIRSIZE];

struct blist
{
    int bno;
    struct blist *next;
} *curr, *prev;

int bitvector[DISKSIZE];

void main()
{
    int choice = 0, i, j, k, n, fi, fcnt = -1;
    char fname[14];

    for (i = 0; i < DISKSIZE; i++){
        bitvector[i] = random() % 2;
    }

    while (1){
        printf("\n\n1. Print Bit Vector");
        printf("\n2. Create File");
        printf("\n3. Print Directory");
        printf("\n4. Delete File");
        printf("\n5. Exit");
        printf("\nEnter Your Choice : ");
        scanf("%d", &choice);
        switch (choice)
        {
        case 1:
            for (i = 0; i < DISKSIZE; i++)
                printf("%2d", bitvector[i]);
            break;
        case 2:
            printf("\nEnter A Filename : ");
            scanf("%s", dir[++fcnt].fname);
            dir[fcnt].first = NULL;
            dir[fcnt].deleted = 0;
            printf("\nEnter The Number of Blocks To Allocate : ");
            scanf("%d", &n);

            for (i = 0; i < DISKSIZE; i++)
            {
                if (bitvector[i] == 0) // found free block
                {
                    bitvector[i] = 1; // Allocate the block
                    curr = (struct blist *)malloc(sizeof(struct blist));
                    curr->bno = i;
                    curr->next = NULL;
                    if (dir[fcnt].first == NULL)
                    {
                        dir[fcnt].first = curr;
                        prev = curr;
                    }
                    else
                    {
                        prev->next = curr;
                        prev = curr;
                    }
                    n--;
                    if (n == 0)
                        break;
                }
            }
            break;
        case 3:
            printf("\nDirectory : ");
            printf("\n----------------------------------");
            printf("\nFilename     Block Numbers");
            printf("\n----------------------------------");
            for (fi = 0; fi <= fcnt; fi++)
                if (dir[fi].deleted != 1)
                {
                    printf("\n%-10s", dir[fi].fname);
                    for (curr = dir[fi].first; curr != NULL; curr = curr->next)
                        printf("%4d", curr->bno);
                }
            printf("\n-----------------------------------");
            break;
        case 4:
            printf("\nEnter a Filename : ");
            scanf("%s", fname);
            for (fi = 0; fi <= fcnt; fi++)
            {
                if (strcmp(dir[fi].fname, fname) == 0)
                    break;
            }
            if (fi <= fcnt) // file found
            {
                dir[fi].deleted = 1;
                for (curr = dir[fi].first; curr != NULL; curr = curr->next)
                    bitvector[curr->bno] = 0; // free blocks
            }
            else
                printf("\nFile not found..\n");
            break;
        case 5:
            exit(0);
        }
    }
}