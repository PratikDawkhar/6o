//contiguous

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#define DISKSIZE 100
#define DIRSIZE 20

struct direntry
{
    char fname[14];
    int start, count, deleted;
} dir[DIRSIZE];

int bitvector[DISKSIZE]; // stores allocated and free block info

void main()
{
    int choice = 0, i, j, k, n, fi, fcnt = -1;
    char fname[14];

    for (i=0;i<DISKSIZE;i++){
        bitvector[i] = random() % 2;
    }

    while (1)
    {
        printf("\n\n1. Print Bit Vector");
        printf("\n2. Create File");
        printf("\n3. Print Directory");
        printf("\n4. Delete File");
        printf("\n5. Exit");
        printf("\nEnter Your Choice : ");
        scanf("%d", &choice);
        switch (choice)
        {
        case 1:
            for (i = 0; i < DISKSIZE; i++)
                printf("%2d", bitvector[i]);
            break;
        case 2:
            printf("\nEnter A Filename : ");
            scanf("%s", dir[++fcnt].fname);
            dir[fcnt].deleted = 0;
            printf("\nEnter The Number of Blocks To Allocate : ");
            scanf("%d", &n);
            dir[fcnt].count = n;

            for (i = 0; i < DISKSIZE; i++){
                if (bitvector[i] == 0) // found free block
                {
                    for (j = i; j < i + n; j++) // find next n-1 free blocks
                    {
                        if (bitvector[j] != 0) // not free
                            break;
                    } // for

                    if (j == i + n) // found n contiguous free blocks
                    {
                        dir[fcnt].start = i;
                        for (k = i; k < j; k++) // allocate blocks
                            bitvector[k] = 1;
                        break;
                    } // if
                }     // outer if
            }         // for
            break;
        case 3:
            printf("\nDirectory : ");
            printf("\n--------------------------");
            printf("\nFilename     Start  Count");
            printf("\n--------------------------");
            for (fi = 0; fi <= fcnt; fi++)
                if (dir[fi].deleted != 1)
                    printf("\n%-10s %5d %5d", dir[fi].fname, dir[fi].start, dir[fi].count);
            printf("\n--------------------------");
            break;
        case 4:
            printf("\nEnter a Filename to delete: ");
            scanf("%s", fname);
            for (fi = 0; fi <= fcnt; fi++)
            {
                if (strcmp(dir[fi].fname, fname) == 0)
                    break;
            }
            if (fi <= fcnt) // file found
            {
                dir[fi].deleted = 1;
                for (i = dir[fi].start; i < dir[fi].start + dir[fi].count; i++)
                    bitvector[i] = 0; // free blocks
            }
            else
                printf("\nFile not found..\n");
            break;
        case 5:
            exit(0);
        }
    }
}