#include <stdio.h>
#include <stdlib.h>

int main() {
    int request[] = {186, 89, 44, 70, 102, 22, 51, 124};
    int n = 8, hpos = 60, thmov = 0;

    printf("Current head position: %d\n", hpos);

    while (n--) {
        int j = 0, stdist = abs(request[0] - hpos);
        for (int i = 1; i <= n; i++) {
            if (abs(request[i] - hpos) < stdist) {
                j = i;
                stdist = abs(request[i] - hpos);
            }
        }
        hpos = request[j], thmov += stdist;
        printf("Current head position: %d\n", hpos);
        for (int i = j; i < n; i++) request[i] = request[i + 1];
    }

    printf("Total head movements: %d\n", thmov);
    return 0;
}
